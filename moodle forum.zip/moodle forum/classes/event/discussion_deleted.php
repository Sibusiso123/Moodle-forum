<?php


namespace mod_moodleforum\event;
defined('MOODLE_INTERNAL') || die();


class discussion_deleted extends \core\event\base {

  
    protected function init() {
        $this->data['crud']        = 'd';
        $this->data['edulevel']    = self::LEVEL_OTHER;
        $this->data['objecttable'] = 'moodleforum_discussions';
    }

   
    public function get_description() {
        return "The user with id '$this->userid' has deleted the discussion with id '$this->objectid' in the moodleforum " .
            "with course module id '$this->contextinstanceid'.";
    }

   
    public static function get_name() {
        return get_string('eventdiscussiondeleted', 'mod_moodleforum');
    }
}

