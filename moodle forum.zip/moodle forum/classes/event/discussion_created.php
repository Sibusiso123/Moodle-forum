<?php


namespace mod_moodleforum\event;
defined('MOODLE_INTERNAL') || die();


class discussion_created extends \core\event\base {

    public function get_description() {
        return "The user with id '$this->userid' has created the discussion with id '$this->objectid' in the moodleforum " .
            "with course module id '$this->contextinstanceid'.";
    }

    /**
     * Return localised event name.
     *
     * @return string
     */
    public static function get_name() {
        return get_string('eventdiscussioncreated', 'mod_moodleforum');
    }

}
