<?php

namespace mod_moodleforum\event;
defined('MOODLE_INTERNAL') || die();


class course_module_instance_list_viewed extends \core\event\course_module_instance_list_viewed {
    // No need for any code here as everything is handled by the parent class.
}
