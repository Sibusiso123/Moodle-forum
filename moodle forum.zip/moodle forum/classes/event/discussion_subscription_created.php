<?php

namespace mod_moodleforum\event;
defined('MOODLE_INTERNAL') || die();

/**
 * The mod_moodleforum discussion_subscription created event class.
 *
 * @property-read array $other {
 *      Extra information about the event.
 *
 *      - int moodleforumid: The id of the moodleforum which the discussion is in.
 *      - int discussion: The id of the discussion which has been subscribed to.
 * }
 *
 * @package   mod_moodleforum
 * @copyright 2017 Kennet Winter <k_wint10@uni-muenster.de>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class discussion_subscription_created extends \core\event\base {
    /**
     * Init method.
     *
     * @return void
     */
    protected function init() {
        $this->data['crud']        = 'c';
        $this->data['edulevel']    = self::LEVEL_PARTICIPATING;
        $this->data['objecttable'] = 'moodleforum_discuss_subs';
    }

    /**
     * Returns description of what happened.
     *
     * @return string
     */
    public function get_description() {
        return "The user with id '$this->userid' subscribed the user with id '$this->relateduserid' to the discussion " .
            " with id '{$this->other['discussion']}' in the moodleforum with the course module id '$this->contextinstanceid'.";
    }

    /**
     * Return localised event name.
     *
     * @return string
     */
    public static function get_name() {
        return get_string('eventdiscussionsubscriptioncreated', 'mod_moodleforum');
    }

}
